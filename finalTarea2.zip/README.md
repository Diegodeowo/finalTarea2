# Tarea Programa 2 

Este programa programa permite obtener información de empleados, dependiendo si son empleados de nomina o profeisonales por hora.

## Autor
Programa realizado por Juan Diego Soto Castro, carnet: C07722. Estudiante de la Universidad de Costa Rica a modo de tarea programada 2 del curso: Programación II.

Github: Diegodeowo

E-mail: juan.sotocastro@ucr.ac.cr

## Como ejecutar el código

Usar el comando "Makefile" de la siguiente manera

```bash
make
```
Luego de esperar el tiempo necesario para su compilación usar

```bash
./bin/a
```
## Como ejecutar GTEST
```bash
make test1
```
### Para ejecutar cualquier test utilizar:
```bash
./bin/tests1
```
## Contribuidores:
- Mauricio Ulate: Profesor y guía del proyecto.